# ===============================================================================
# K-Food 웹플랫폼 프로젝트 - 연구 로그 시스템 쉘 설정
# 
# 사용법: 
#   source ~/.bashrc 또는 source ~/.zshrc 에 아래 내용 추가
#   또는 이 파일을 직접 source
# ===============================================================================

# 프로젝트 경로 설정 (실제 경로로 수정)
export KFOOD_PROJECT_ROOT="${KFOOD_PROJECT_ROOT:-$HOME/projects/k-food-platform}"
export AUTHOR_NAME="${AUTHOR_NAME:-Jae-Hoon}"

# Obsidian 볼트 경로 (사용하는 경우)
export OBSIDIAN_VAULT="${OBSIDIAN_VAULT:-$HOME/Documents/ObsidianVault}"

# -------------------------------------------------------------------------------
# 별칭 설정
# -------------------------------------------------------------------------------

# 새 연구 세션 로그 생성
alias logp="PROJECT_ROOT=\$KFOOD_PROJECT_ROOT \$KFOOD_PROJECT_ROOT/scripts/log-prompt.sh"

# 오늘 로그 목록
alias logl="PROJECT_ROOT=\$KFOOD_PROJECT_ROOT \$KFOOD_PROJECT_ROOT/scripts/log-prompt.sh -l"

# 마지막 로그 커밋
alias logc="PROJECT_ROOT=\$KFOOD_PROJECT_ROOT \$KFOOD_PROJECT_ROOT/scripts/log-prompt.sh -c"

# Obsidian 동기화
alias logs="PROJECT_ROOT=\$KFOOD_PROJECT_ROOT \$KFOOD_PROJECT_ROOT/scripts/sync-obsidian.sh sync"

# -------------------------------------------------------------------------------
# 함수 정의
# -------------------------------------------------------------------------------

# 빠른 프롬프트 기록 (한 줄로)
# 사용법: qlog "여기에 프롬프트 내용"
qlog() {
    local prompt_text="$*"
    local log_dir="${KFOOD_PROJECT_ROOT}/docs/research-logs/$(date +%Y-%m)"
    local today=$(date +%Y%m%d)
    local timestamp=$(date +%Y-%m-%dT%H:%M:%S%z)
    
    mkdir -p "$log_dir"
    
    # 기존 파일 수 확인하여 세션 번호 결정
    local session_num=$(printf "%03d" $(($(ls -1 "${log_dir}/${today}_session_"*.md 2>/dev/null | wc -l) + 1)))
    local filename="${today}_session_${session_num}.md"
    local filepath="${log_dir}/${filename}"
    
    cat > "$filepath" << EOF
# 연구 세션 로그: $(date +%Y-%m-%d) #${session_num}

## 메타데이터

| 항목 | 값 |
|------|-----|
| 일시 | ${timestamp} |
| 작성자 | ${AUTHOR_NAME} |
| 관련 커밋 | $(git -C "$KFOOD_PROJECT_ROOT" rev-parse --short HEAD 2>/dev/null || echo "N/A") |

---

## 질문 (Prompt)

\`\`\`
${prompt_text}
\`\`\`

---

## 응답 요약

[추후 작성]

---

## 착상 기록

[추후 작성]

EOF
    
    echo "✓ 로그 생성: $filepath"
    echo "  편집: code $filepath"
}

# Claude Code 세션 시작 래퍼
# 사용법: ccstart "세션 목적 설명"
ccstart() {
    local purpose="$*"
    echo "═══════════════════════════════════════════════════════════════════════════════"
    echo " Claude Code 세션 시작"
    echo " 목적: ${purpose:-미지정}"
    echo " 시각: $(date +%Y-%m-%dT%H:%M:%S%z)"
    echo "═══════════════════════════════════════════════════════════════════════════════"
    
    # 로그 생성
    logp
    
    echo ""
    echo "[TIP] 세션 종료 후 'logc'로 커밋하세요."
}

# 증거 패키지 생성
# 사용법: evidence [날짜범위]
evidence() {
    local range="${1:-all}"
    PROJECT_ROOT="$KFOOD_PROJECT_ROOT" "$KFOOD_PROJECT_ROOT/scripts/sync-obsidian.sh" package "$range"
}

# 연구 로그 검색
# 사용법: logsearch "검색어"
logsearch() {
    local query="$*"
    local log_dir="${KFOOD_PROJECT_ROOT}/docs/research-logs"
    
    echo "검색어: $query"
    echo "───────────────────────────────────────────────────────────────────────────────"
    grep -r -n -i --include="*.md" "$query" "$log_dir" | head -20
}

# Git GPG 서명 커밋 (연구 로그용)
# 사용법: gcs "커밋 메시지"
gcs() {
    local msg="${1:-docs: 연구 세션 로그 추가}"
    git -C "$KFOOD_PROJECT_ROOT" add docs/research-logs/
    git -C "$KFOOD_PROJECT_ROOT" commit -S -m "$msg"
    echo "✓ GPG 서명 커밋 완료: $msg"
}

# -------------------------------------------------------------------------------
# 자동 완성 설정 (bash)
# -------------------------------------------------------------------------------

if [ -n "$BASH_VERSION" ]; then
    _logp_completions() {
        local cur="${COMP_WORDS[COMP_CWORD]}"
        COMPREPLY=($(compgen -W "-n --new -l --list -e --edit -c --commit -h --help" -- "$cur"))
    }
    complete -F _logp_completions logp
fi

# -------------------------------------------------------------------------------
# 자동 완성 설정 (zsh)
# -------------------------------------------------------------------------------

if [ -n "$ZSH_VERSION" ]; then
    _logp() {
        local -a options
        options=(
            '-n:새 세션 로그 생성'
            '--new:새 세션 로그 생성'
            '-l:오늘 로그 목록'
            '--list:오늘 로그 목록'
            '-e:세션 편집'
            '--edit:세션 편집'
            '-c:마지막 로그 커밋'
            '--commit:마지막 로그 커밋'
            '-h:도움말'
            '--help:도움말'
        )
        _describe 'logp options' options
    }
    compdef _logp logp
fi

# -------------------------------------------------------------------------------
# 초기화 메시지
# -------------------------------------------------------------------------------

echo "🔬 K-Food 연구 로그 시스템 로드됨"
echo "   logp  - 새 세션 로그     logl  - 오늘 목록"
echo "   logc  - 커밋             qlog  - 빠른 기록"
