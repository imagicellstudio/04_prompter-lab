#!/bin/bash
#===============================================================================
# 프롬프트 로그 시스템 설치 스크립트
# 용도: K-Food 웹플랫폼 프로젝트에 연구 로그 시스템 설치
#===============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}===============================================================================${NC}"
echo -e "${BLUE} 프롬프트 로그 시스템 설치${NC}"
echo -e "${BLUE} K-Food 웹플랫폼 프로젝트 - 연구 노트 자동화${NC}"
echo -e "${BLUE}===============================================================================${NC}"
echo ""

#-------------------------------------------------------------------------------
# 1. 프로젝트 루트 확인
#-------------------------------------------------------------------------------
PROJECT_ROOT="${1:-$(pwd)}"

if [ ! -d "$PROJECT_ROOT/.git" ]; then
    echo -e "${RED}[ERROR]${NC} Git 저장소가 아닙니다: $PROJECT_ROOT"
    echo "사용법: ./install.sh [프로젝트_경로]"
    exit 1
fi

echo -e "${GREEN}[INFO]${NC} 설치 대상: $PROJECT_ROOT"

#-------------------------------------------------------------------------------
# 2. 디렉토리 구조 생성
#-------------------------------------------------------------------------------
echo -e "${YELLOW}[STEP 1]${NC} 디렉토리 구조 생성..."

DIRS=(
    "docs/research-logs"
    "docs/research-logs/templates"
    "docs/research-logs/scans"
    "scripts"
)

for dir in "${DIRS[@]}"; do
    mkdir -p "${PROJECT_ROOT}/${dir}"
    echo "  생성: ${dir}/"
done

#-------------------------------------------------------------------------------
# 3. 스크립트 복사
#-------------------------------------------------------------------------------
echo -e "${YELLOW}[STEP 2]${NC} 스크립트 복사..."

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# log-prompt.sh 복사
if [ -f "${SCRIPT_DIR}/scripts/log-prompt.sh" ]; then
    cp "${SCRIPT_DIR}/scripts/log-prompt.sh" "${PROJECT_ROOT}/scripts/"
    chmod +x "${PROJECT_ROOT}/scripts/log-prompt.sh"
    echo "  복사: scripts/log-prompt.sh"
else
    # 현재 디렉토리에서 찾기
    PARENT_DIR="$(dirname "$SCRIPT_DIR")"
    if [ -f "${PARENT_DIR}/scripts/log-prompt.sh" ]; then
        cp "${PARENT_DIR}/scripts/log-prompt.sh" "${PROJECT_ROOT}/scripts/"
        chmod +x "${PROJECT_ROOT}/scripts/log-prompt.sh"
        echo "  복사: scripts/log-prompt.sh"
    fi
fi

#-------------------------------------------------------------------------------
# 4. Git Hooks 설치
#-------------------------------------------------------------------------------
echo -e "${YELLOW}[STEP 3]${NC} Git Hooks 설치..."

HOOKS_SOURCE="${SCRIPT_DIR}/../git-hooks"
if [ ! -d "$HOOKS_SOURCE" ]; then
    HOOKS_SOURCE="${SCRIPT_DIR}/git-hooks"
fi

HOOKS_TARGET="${PROJECT_ROOT}/.git/hooks"

for hook in pre-commit post-commit; do
    if [ -f "${HOOKS_SOURCE}/${hook}" ]; then
        cp "${HOOKS_SOURCE}/${hook}" "${HOOKS_TARGET}/"
        chmod +x "${HOOKS_TARGET}/${hook}"
        echo "  설치: .git/hooks/${hook}"
    fi
done

#-------------------------------------------------------------------------------
# 5. .gitignore 업데이트
#-------------------------------------------------------------------------------
echo -e "${YELLOW}[STEP 4]${NC} .gitignore 업데이트..."

GITIGNORE="${PROJECT_ROOT}/.gitignore"

# 추가할 항목
IGNORE_ENTRIES=(
    "# 연구 로그 시스템 - 임시 파일"
    "docs/research-logs/.commit-history.log"
    "docs/research-logs/.evidence-chain.log"
    "*.swp"
    "*.swo"
    "*~"
)

for entry in "${IGNORE_ENTRIES[@]}"; do
    if ! grep -Fxq "$entry" "$GITIGNORE" 2>/dev/null; then
        echo "$entry" >> "$GITIGNORE"
    fi
done
echo "  업데이트: .gitignore"

#-------------------------------------------------------------------------------
# 6. 인덱스 파일 생성
#-------------------------------------------------------------------------------
echo -e "${YELLOW}[STEP 5]${NC} 인덱스 파일 생성..."

INDEX_FILE="${PROJECT_ROOT}/docs/research-logs/INDEX.md"

if [ ! -f "$INDEX_FILE" ]; then
    cat > "$INDEX_FILE" << 'EOF'
# 연구 세션 로그 인덱스

K-Food 웹플랫폼 프로젝트 Claude Code 대화 기록

## 목적

이 디렉토리는 Claude Code와의 모든 대화 내용을 체계적으로 기록하여:

1. **발명 착상일(conception date)** 증명
2. **선행 연구 증거** 확보
3. **특허 출원 시 증거 자료** 제공

을 목적으로 합니다.

## 디렉토리 구조

```
docs/research-logs/
├── INDEX.md              # 이 파일
├── templates/            # 로그 템플릿
├── scans/                # 물리적 연구노트 스캔본
└── YYYY-MM/              # 월별 로그 디렉토리
    └── YYYYMMDD_session_NNN.md
```

## 사용 방법

```bash
# 새 세션 로그 생성
./scripts/log-prompt.sh

# 오늘 로그 목록 확인
./scripts/log-prompt.sh -l

# 특정 세션 편집
./scripts/log-prompt.sh -e 001
```

## 세션 목록

| 날짜 | 시간 | 세션 | 파일 | 주요 내용 |
|------|------|------|------|----------|
EOF
    echo "  생성: docs/research-logs/INDEX.md"
fi

#-------------------------------------------------------------------------------
# 7. README 생성
#-------------------------------------------------------------------------------
README_FILE="${PROJECT_ROOT}/docs/research-logs/README.md"

cat > "$README_FILE" << 'EOF'
# 연구 로그 시스템

## 개요

이 시스템은 Claude Code와의 대화 내용을 자동으로 기록하여 지적 재산권 보호를 위한 증거를 축적합니다.

## 증거력 확보 요소

1. **Git 타임스탬프**: 커밋 시각이 GitHub 서버에 기록
2. **GPG 서명**: 작성자 신원 증명 (권장)
3. **해시 체인**: 각 로그 파일에 고유 해시 포함
4. **물리적 연구노트 연동**: `scans/` 디렉토리에 스캔본 보관

## 법적 고려사항

- 한국 특허법상 **선출원주의**이나, 착상일 증명은 분쟁 시 유효
- 미국 특허법(AIA) 하에서도 선행 발명 증거로 활용 가능
- 저작권 등록 시 창작일 증명에 활용

## 권장 워크플로우

1. Claude Code 세션 시작 전 `./scripts/log-prompt.sh` 실행
2. 생성된 파일에 질문 복사/붙여넣기
3. 세션 종료 후 응답 요약 및 착상 기록 작성
4. GPG 서명 커밋: `git commit -S -m "docs: 연구 세션 로그"`
5. 물리적 연구노트에 디지털 세션 참조 기록

## 연락처

프로젝트: K-Food 웹플랫폼 서비스
EOF

echo "  생성: docs/research-logs/README.md"

#-------------------------------------------------------------------------------
# 8. GPG 설정 안내
#-------------------------------------------------------------------------------
echo ""
echo -e "${YELLOW}[STEP 6]${NC} GPG 서명 설정 확인..."

if git config --get user.signingkey > /dev/null 2>&1; then
    echo -e "  ${GREEN}[OK]${NC} GPG 서명 키 설정됨: $(git config --get user.signingkey)"
else
    echo -e "  ${YELLOW}[NOTICE]${NC} GPG 서명이 설정되지 않았습니다."
    echo ""
    echo "  증거력 강화를 위해 GPG 서명 설정을 권장합니다:"
    echo ""
    echo "  # GPG 키 생성 (없는 경우)"
    echo "  gpg --full-generate-key"
    echo ""
    echo "  # 키 ID 확인"
    echo "  gpg --list-secret-keys --keyid-format=long"
    echo ""
    echo "  # Git에 설정"
    echo "  git config --global user.signingkey YOUR_KEY_ID"
    echo "  git config --global commit.gpgsign true"
fi

#-------------------------------------------------------------------------------
# 9. 완료
#-------------------------------------------------------------------------------
echo ""
echo -e "${GREEN}===============================================================================${NC}"
echo -e "${GREEN} 설치 완료!${NC}"
echo -e "${GREEN}===============================================================================${NC}"
echo ""
echo "사용 방법:"
echo ""
echo "  # 새 세션 로그 생성"
echo "  cd $PROJECT_ROOT"
echo "  ./scripts/log-prompt.sh"
echo ""
echo "  # 또는 어디서든 실행"
echo "  PROJECT_ROOT=$PROJECT_ROOT ./scripts/log-prompt.sh"
echo ""
echo -e "${YELLOW}[TIP]${NC} 자주 사용한다면 alias 설정을 추천합니다:"
echo "  alias logp='${PROJECT_ROOT}/scripts/log-prompt.sh'"
echo ""
