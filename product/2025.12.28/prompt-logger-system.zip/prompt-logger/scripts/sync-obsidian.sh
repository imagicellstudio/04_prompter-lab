#!/bin/bash
#===============================================================================
# Obsidian 연구노트 연동 스크립트
# 용도: 물리적 연구노트와 디지털 세션 로그 간 상호 참조 생성
#===============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 설정
PROJECT_ROOT="${PROJECT_ROOT:-$(git rev-parse --show-toplevel 2>/dev/null || pwd)}"
LOG_DIR="${PROJECT_ROOT}/docs/research-logs"
OBSIDIAN_VAULT="${OBSIDIAN_VAULT:-$HOME/Documents/ObsidianVault}"

#-------------------------------------------------------------------------------
# 함수 정의
#-------------------------------------------------------------------------------

# 양방향 링크 생성
create_bidirectional_link() {
    local session_file=$1
    local notebook_page=$2
    
    # 세션 파일에 Obsidian 링크 추가
    if [ -f "$session_file" ]; then
        if ! grep -q "Obsidian 링크:" "$session_file"; then
            echo "" >> "$session_file"
            echo "## Obsidian 연동" >> "$session_file"
            echo "" >> "$session_file"
            echo "- Obsidian 링크: [[${notebook_page}]]" >> "$session_file"
            echo -e "${GREEN}[INFO]${NC} 세션 파일에 Obsidian 링크 추가: $session_file"
        fi
    fi
    
    # Obsidian 볼트에 역방향 링크 생성
    local obsidian_file="${OBSIDIAN_VAULT}/Research/${notebook_page}.md"
    
    if [ -d "$OBSIDIAN_VAULT" ]; then
        mkdir -p "$(dirname "$obsidian_file")"
        
        if [ ! -f "$obsidian_file" ]; then
            local session_name=$(basename "$session_file" .md)
            local session_date=$(echo "$session_name" | cut -c1-8)
            local formatted_date="${session_date:0:4}-${session_date:4:2}-${session_date:6:2}"
            
            cat > "$obsidian_file" << EOF
---
date: ${formatted_date}
type: research-session
project: K-Food 웹플랫폼
tags:
  - claude-code
  - research-log
---

# ${notebook_page}

## 디지털 세션 참조

- Git 세션 로그: [[${session_name}]]
- 파일 경로: \`docs/research-logs/$(date +%Y-%m)/${session_name}.md\`

## 물리적 연구노트 매핑

- 연구노트 번호: 
- 페이지 범위: 
- 스캔 파일: 

## 핵심 내용

[여기에 핵심 내용 요약]

## 관련 링크

- 

EOF
            echo -e "${GREEN}[INFO]${NC} Obsidian 노트 생성: $obsidian_file"
        else
            echo -e "${YELLOW}[SKIP]${NC} Obsidian 노트 이미 존재: $obsidian_file"
        fi
    else
        echo -e "${YELLOW}[WARNING]${NC} Obsidian 볼트를 찾을 수 없습니다: $OBSIDIAN_VAULT"
        echo "  OBSIDIAN_VAULT 환경변수를 설정하세요."
    fi
}

# 최근 세션에 대해 연동 실행
sync_recent_sessions() {
    local count=${1:-5}
    local sessions=$(find "$LOG_DIR" -name "*.md" -not -name "INDEX.md" -not -name "README.md" | sort -r | head -n "$count")
    
    echo -e "${YELLOW}최근 ${count}개 세션 동기화...${NC}"
    
    for session in $sessions; do
        local session_name=$(basename "$session" .md)
        local notebook_page="RN-$(echo "$session_name" | sed 's/_session_/-/' | cut -c1-12)"
        
        create_bidirectional_link "$session" "$notebook_page"
    done
}

# 물리적 연구노트 스캔본 등록
register_scan() {
    local scan_file=$1
    local notebook_page=$2
    
    if [ ! -f "$scan_file" ]; then
        echo -e "${RED}[ERROR]${NC} 스캔 파일을 찾을 수 없습니다: $scan_file"
        exit 1
    fi
    
    local scans_dir="${LOG_DIR}/scans"
    mkdir -p "$scans_dir"
    
    local ext="${scan_file##*.}"
    local target_file="${scans_dir}/${notebook_page}.${ext}"
    
    cp "$scan_file" "$target_file"
    echo -e "${GREEN}[INFO]${NC} 스캔본 등록: $target_file"
    
    # Git에 추가
    git add "$target_file"
    echo -e "${GREEN}[INFO]${NC} Git 스테이징 완료"
}

# 증거 패키지 생성 (특허 출원용)
create_evidence_package() {
    local output_dir="${1:-${PROJECT_ROOT}/evidence-package}"
    local date_range="${2:-all}"
    
    mkdir -p "$output_dir"
    
    echo -e "${YELLOW}증거 패키지 생성 중...${NC}"
    
    # 1. 세션 로그 복사
    if [ "$date_range" = "all" ]; then
        cp -r "$LOG_DIR"/* "$output_dir/"
    else
        find "$LOG_DIR" -name "${date_range}*.md" -exec cp {} "$output_dir/" \;
    fi
    
    # 2. Git 로그 추출
    git log --pretty=format:"%H|%ai|%s|%GG" -- "$LOG_DIR" > "${output_dir}/git-history.csv"
    
    # 3. 해시 목록 생성
    find "$output_dir" -name "*.md" -exec sha256sum {} \; > "${output_dir}/file-hashes.txt"
    
    # 4. 메타데이터 생성
    cat > "${output_dir}/EVIDENCE_METADATA.md" << EOF
# 연구 증거 패키지

생성 일시: $(date +%Y-%m-%dT%H:%M:%S%z)
프로젝트: K-Food 웹플랫폼 서비스
범위: ${date_range}

## 포함 내용

- 연구 세션 로그: $(find "$output_dir" -name "*_session_*.md" | wc -l) 건
- 스캔 파일: $(find "$output_dir/scans" -type f 2>/dev/null | wc -l) 건
- Git 커밋 이력: $(wc -l < "${output_dir}/git-history.csv") 건

## 무결성 검증

파일 해시 목록: file-hashes.txt
Git 이력: git-history.csv

## 법적 고지

이 패키지는 지적 재산권 증명을 위한 증거 자료입니다.
각 파일의 타임스탬프와 Git 커밋 기록이 작성 시점을 증명합니다.
EOF

    # 5. 압축
    local archive_name="evidence-package-$(date +%Y%m%d-%H%M%S).tar.gz"
    tar -czf "${PROJECT_ROOT}/${archive_name}" -C "$(dirname "$output_dir")" "$(basename "$output_dir")"
    
    echo -e "${GREEN}[SUCCESS]${NC} 증거 패키지 생성 완료: ${archive_name}"
    
    # 해시 출력 (분쟁 시 무결성 검증용)
    echo ""
    echo "패키지 SHA256 해시:"
    sha256sum "${PROJECT_ROOT}/${archive_name}"
}

#-------------------------------------------------------------------------------
# 메인
#-------------------------------------------------------------------------------

show_help() {
    cat << EOF
===============================================================================
Obsidian 연구노트 연동 스크립트
===============================================================================

사용법:
  ./sync-obsidian.sh [명령] [옵션]

명령:
  sync [N]          최근 N개 세션 동기화 (기본: 5)
  scan FILE PAGE    스캔본 등록 (예: scan notebook.pdf RN-2025-1228-001)
  package [RANGE]   증거 패키지 생성 (예: package 202512 또는 package all)

환경변수:
  OBSIDIAN_VAULT    Obsidian 볼트 경로 (기본: ~/Documents/ObsidianVault)
  PROJECT_ROOT      프로젝트 루트 경로

예시:
  ./sync-obsidian.sh sync 10
  ./sync-obsidian.sh scan ~/Desktop/scan.pdf RN-2025-1228-001
  ./sync-obsidian.sh package 202512

===============================================================================
EOF
}

case "${1:-}" in
    sync)
        sync_recent_sessions "${2:-5}"
        ;;
    scan)
        register_scan "$2" "$3"
        ;;
    package)
        create_evidence_package "${PROJECT_ROOT}/evidence-package" "${2:-all}"
        ;;
    -h|--help|"")
        show_help
        ;;
    *)
        echo -e "${RED}[ERROR]${NC} 알 수 없는 명령: $1"
        show_help
        exit 1
        ;;
esac
