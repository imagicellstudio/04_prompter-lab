#!/bin/bash
#===============================================================================
# 프롬프트 로그 기록 스크립트
# 용도: Claude Code 대화 내용을 연구노트 형식으로 Git 저장소에 기록
# 작성: K-Food 웹플랫폼 프로젝트용
#===============================================================================

set -e

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

#-------------------------------------------------------------------------------
# 설정값 (프로젝트에 맞게 수정)
#-------------------------------------------------------------------------------
PROJECT_ROOT="${PROJECT_ROOT:-$(git rev-parse --show-toplevel 2>/dev/null || pwd)}"
LOG_DIR="${PROJECT_ROOT}/docs/research-logs"
TEMPLATE_DIR="${PROJECT_ROOT}/docs/research-logs/templates"
AUTHOR_NAME="${AUTHOR_NAME:-Jae-Hoon}"
RESEARCH_NOTEBOOK_PREFIX="RN-2025"

#-------------------------------------------------------------------------------
# 함수 정의
#-------------------------------------------------------------------------------

# 오늘 날짜 디렉토리 생성
create_date_dir() {
    local year_month=$(date +%Y-%m)
    local dir_path="${LOG_DIR}/${year_month}"
    
    if [ ! -d "$dir_path" ]; then
        mkdir -p "$dir_path"
        echo -e "${GREEN}[INFO]${NC} 디렉토리 생성: $dir_path"
    fi
    
    echo "$dir_path"
}

# 세션 번호 생성 (당일 기준 자동 증가)
get_session_number() {
    local date_dir=$1
    local today=$(date +%Y%m%d)
    local existing_count=$(ls -1 "${date_dir}/${today}_session_"*.md 2>/dev/null | wc -l)
    printf "%03d" $((existing_count + 1))
}

# 현재 Git 커밋 해시 조회
get_current_commit() {
    git rev-parse --short HEAD 2>/dev/null || echo "uncommitted"
}

# 프롬프트 로그 파일 생성
create_log_file() {
    local date_dir=$1
    local session_num=$2
    local today=$(date +%Y%m%d)
    local timestamp=$(date +%Y-%m-%dT%H:%M:%S%z)
    local filename="${today}_session_${session_num}.md"
    local filepath="${date_dir}/${filename}"
    local commit_hash=$(get_current_commit)
    local notebook_page="${RESEARCH_NOTEBOOK_PREFIX}-$(date +%m%d)-${session_num}"
    
    cat > "$filepath" << EOF
# 연구 세션 로그: $(date +%Y-%m-%d) #${session_num}

## 메타데이터

| 항목 | 값 |
|------|-----|
| 일시 | ${timestamp} |
| 작성자 | ${AUTHOR_NAME} |
| 관련 커밋 | ${commit_hash} |
| 연구노트 페이지 | ${notebook_page} |
| 프로젝트 | K-Food 웹플랫폼 서비스 |

---

## 질문 (Prompt)

\`\`\`
[여기에 Claude Code에 입력한 질문 전문을 붙여넣으세요]


\`\`\`

---

## 응답 요약

[핵심 결과물 요약 - 3줄 이내]

---

## 산출물

### 생성된 파일
- 

### 수정된 파일
- 

---

## 착상 기록 (Conception Notes)

### 새로운 아이디어
[이 세션에서 도출된 새로운 아이디어]

### 기술적 해결책
[발견한 기술적 해결 방법]

### 특허 관련 메모
[특허 출원 가능성이 있는 내용 기록]

---

## 후속 작업

- [ ] 
- [ ] 

---

## 서명

- 기록자: ${AUTHOR_NAME}
- 기록 시각: ${timestamp}
- 파일 해시: $(echo "${timestamp}${AUTHOR_NAME}${session_num}" | sha256sum | cut -c1-16)

EOF

    echo "$filepath"
}

# 인덱스 파일 업데이트
update_index() {
    local log_file=$1
    local index_file="${LOG_DIR}/INDEX.md"
    local today=$(date +%Y-%m-%d)
    local timestamp=$(date +%H:%M)
    local filename=$(basename "$log_file")
    local relative_path=$(realpath --relative-to="$LOG_DIR" "$log_file")
    
    # 인덱스 파일이 없으면 생성
    if [ ! -f "$index_file" ]; then
        cat > "$index_file" << 'EOF'
# 연구 세션 로그 인덱스

K-Food 웹플랫폼 프로젝트 Claude Code 대화 기록

## 세션 목록

| 날짜 | 시간 | 세션 | 파일 | 주요 내용 |
|------|------|------|------|----------|
EOF
    fi
    
    # 새 항목 추가
    echo "| ${today} | ${timestamp} | ${filename%.md} | [링크](${relative_path}) | (내용 추가 필요) |" >> "$index_file"
    
    echo -e "${GREEN}[INFO]${NC} 인덱스 업데이트: $index_file"
}

# Git 자동 커밋 (선택적)
auto_commit() {
    local log_file=$1
    local commit_msg="docs: 연구 세션 로그 추가 - $(basename $log_file .md)"
    
    read -p "Git에 자동 커밋하시겠습니까? (y/N): " response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        git add "$log_file" "${LOG_DIR}/INDEX.md"
        git commit -S -m "$commit_msg" 2>/dev/null || git commit -m "$commit_msg"
        echo -e "${GREEN}[INFO]${NC} Git 커밋 완료: $commit_msg"
    fi
}

# 도움말 출력
show_help() {
    cat << EOF
===============================================================================
프롬프트 로그 기록 스크립트 (log-prompt.sh)
===============================================================================

사용법:
  ./log-prompt.sh [옵션]

옵션:
  -h, --help      이 도움말 출력
  -n, --new       새 세션 로그 생성 (기본 동작)
  -l, --list      오늘의 세션 로그 목록 출력
  -e, --edit NUM  특정 세션 로그 편집 (예: -e 001)
  -c, --commit    마지막 로그 Git 커밋

환경변수:
  PROJECT_ROOT    프로젝트 루트 경로 (기본: Git 루트)
  AUTHOR_NAME     작성자 이름 (기본: Jae-Hoon)

예시:
  ./log-prompt.sh                  # 새 세션 로그 생성
  ./log-prompt.sh -l               # 오늘 로그 목록
  ./log-prompt.sh -e 002           # 세션 002 편집
  AUTHOR_NAME="홍길동" ./log-prompt.sh  # 작성자 지정

===============================================================================
EOF
}

# 오늘의 로그 목록 출력
list_today_logs() {
    local date_dir=$(create_date_dir)
    local today=$(date +%Y%m%d)
    
    echo -e "${BLUE}=== 오늘의 세션 로그 (${today}) ===${NC}"
    ls -1 "${date_dir}/${today}_session_"*.md 2>/dev/null || echo "(로그 없음)"
}

# 특정 세션 편집
edit_session() {
    local session_num=$1
    local date_dir=$(create_date_dir)
    local today=$(date +%Y%m%d)
    local filepath="${date_dir}/${today}_session_${session_num}.md"
    
    if [ -f "$filepath" ]; then
        ${EDITOR:-vim} "$filepath"
    else
        echo -e "${RED}[ERROR]${NC} 파일을 찾을 수 없습니다: $filepath"
        exit 1
    fi
}

#-------------------------------------------------------------------------------
# 메인 실행부
#-------------------------------------------------------------------------------

main() {
    # 옵션 파싱
    case "${1:-}" in
        -h|--help)
            show_help
            exit 0
            ;;
        -l|--list)
            list_today_logs
            exit 0
            ;;
        -e|--edit)
            edit_session "${2:-001}"
            exit 0
            ;;
        -c|--commit)
            auto_commit "$(ls -t ${LOG_DIR}/*/$(date +%Y%m%d)_session_*.md 2>/dev/null | head -1)"
            exit 0
            ;;
        -n|--new|"")
            # 새 세션 로그 생성 (기본 동작)
            ;;
        *)
            echo -e "${RED}[ERROR]${NC} 알 수 없는 옵션: $1"
            show_help
            exit 1
            ;;
    esac
    
    echo -e "${BLUE}===============================================================================${NC}"
    echo -e "${BLUE} 프롬프트 로그 기록 시스템 - K-Food 웹플랫폼 프로젝트${NC}"
    echo -e "${BLUE}===============================================================================${NC}"
    echo ""
    
    # 디렉토리 생성
    local date_dir=$(create_date_dir)
    
    # 세션 번호 생성
    local session_num=$(get_session_number "$date_dir")
    
    # 로그 파일 생성
    local log_file=$(create_log_file "$date_dir" "$session_num")
    
    echo -e "${GREEN}[SUCCESS]${NC} 세션 로그 생성 완료!"
    echo -e "  파일: ${YELLOW}${log_file}${NC}"
    echo -e "  세션: ${YELLOW}#${session_num}${NC}"
    echo ""
    
    # 인덱스 업데이트
    update_index "$log_file"
    
    echo ""
    echo -e "${YELLOW}[다음 단계]${NC}"
    echo "  1. 생성된 파일을 열어 프롬프트 내용을 붙여넣으세요"
    echo "  2. 응답 요약과 착상 기록을 작성하세요"
    echo "  3. 완료 후 Git 커밋하세요"
    echo ""
    
    # 편집기로 열기
    read -p "지금 편집기로 열까요? (Y/n): " response
    if [[ ! "$response" =~ ^[Nn]$ ]]; then
        ${EDITOR:-vim} "$log_file"
    fi
    
    # Git 커밋 여부
    auto_commit "$log_file"
}

main "$@"
